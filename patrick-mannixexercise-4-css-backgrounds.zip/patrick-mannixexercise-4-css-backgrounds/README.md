# Patrick Mannix - Exercise 4: CSS backgrounds

A Pen created on CodePen.io. Original URL: [https://codepen.io/PatrickMannix/pen/OJooGzv](https://codepen.io/PatrickMannix/pen/OJooGzv).

