# Midterm Mockups Project - Patrick Mannix

A Pen created on CodePen.io. Original URL: [https://codepen.io/PatrickMannix/pen/BaOmjQZ](https://codepen.io/PatrickMannix/pen/BaOmjQZ).

